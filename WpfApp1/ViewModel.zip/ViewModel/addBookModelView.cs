﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;
using System.Configuration;
using System.Data;
using System.Data.SQLite;


namespace WpfApp1.ViewModel
{

    class addBookModelView
    {
        public List<Book> BookList = new List<Book>();

        public void addBook(string Author, string Title, double Year)
        {
            



        }
    }

}
